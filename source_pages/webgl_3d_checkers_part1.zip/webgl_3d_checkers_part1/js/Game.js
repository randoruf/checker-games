var CHECKERS = {};

CHECKERS.Game = function (options) {
    'use strict';
    
    options = options || {};
    
    /**********************************************************************************************/
    /* Private properties *************************************************************************/
   
    /** @type CHECKERS.BoardController */
    var boardController = null;
    
    
    /**********************************************************************************************/
    /* Private methods ****************************************************************************/
   
    /**
     * Initializer.
     */
    function init() {
        boardController = new CHECKERS.BoardController({
            containerEl: options.containerEl,
            assetsUrl: options.assetsUrl
        });
        
        boardController.drawBoard();
    }
    
    init();
};